# Alex
Alex is a terminal music player

## How to install
- Have pip installed
- Have mpv, yt-dlp and youtube-search-python installed