# Alex
Alex is a terminal music player
